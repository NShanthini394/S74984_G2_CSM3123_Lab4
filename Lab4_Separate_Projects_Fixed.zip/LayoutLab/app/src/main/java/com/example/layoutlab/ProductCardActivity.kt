package com.example.layoutlab

import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.layoutlab.databinding.ActivityProductCardBinding

class ProductCardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val binding = ActivityProductCardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.root.applySystemBarInsets()
        binding.btnToggle.setOnClickListener {
            binding.progress.visibility =
                if (binding.progress.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }
}
