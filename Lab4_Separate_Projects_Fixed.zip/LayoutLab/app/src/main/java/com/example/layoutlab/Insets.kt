package com.example.layoutlab

import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

/** Preserve any 16dp XML padding while adding system-bar safe areas. */
fun View.applySystemBarInsets() {
    val left = paddingLeft
    val top = paddingTop
    val right = paddingRight
    val bottom = paddingBottom
    ViewCompat.setOnApplyWindowInsetsListener(this) { view, insets ->
        val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        view.updatePadding(
            left = left + bars.left,
            top = top + bars.top,
            right = right + bars.right,
            bottom = bottom + bars.bottom
        )
        insets
    }
    ViewCompat.requestApplyInsets(this)
}
