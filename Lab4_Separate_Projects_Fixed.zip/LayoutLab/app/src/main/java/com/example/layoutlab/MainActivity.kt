package com.example.layoutlab

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.layoutlab.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.root.applySystemBarInsets()
    binding.btnLinear.setOnClickListener { open(LinearActivity::class.java) }
    binding.btnRelative.setOnClickListener { open(RelativeActivity::class.java) }
    binding.btnConstraint.setOnClickListener { open(ConstraintActivity::class.java) }
    binding.btnFrame.setOnClickListener { open(FrameActivity::class.java) }
    binding.btnTable.setOnClickListener { open(TableActivity::class.java) }
    binding.btnRecycler.setOnClickListener { open(RecyclerActivity::class.java) }
    binding.btnCalculator.setOnClickListener { open(CalculatorActivity::class.java) }
    binding.btnRelativeChallenge.setOnClickListener { open(RelativeChallengeActivity::class.java) }
    binding.btnConstraintChallenge.setOnClickListener { open(ConstraintChallengeActivity::class.java) }
    binding.btnProduct.setOnClickListener { open(ProductCardActivity::class.java) }
    binding.btnTableForm.setOnClickListener { open(TableFormActivity::class.java) }
    binding.btnProfileLinear.setOnClickListener { open(ProfileLinearActivity::class.java) }
    binding.btnProfileConstraint.setOnClickListener { open(ProfileConstraintActivity::class.java) }
    }
    private fun open(target: Class<*>) = startActivity(Intent(this, target))
}
