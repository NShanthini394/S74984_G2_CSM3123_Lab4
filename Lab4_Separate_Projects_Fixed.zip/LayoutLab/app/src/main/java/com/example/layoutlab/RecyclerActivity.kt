package com.example.layoutlab

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.layoutlab.databinding.ActivityRecyclerBinding

class RecyclerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRecyclerBinding
    private var grid = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityRecyclerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.root.applySystemBarInsets()

        val data = List(50) { Student("Student ${it + 1}", 50 + it) }
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = StudentAdapter(data) { student ->
            Toast.makeText(this, student.name, Toast.LENGTH_SHORT).show()
        }
        binding.btnToggle.setOnClickListener {
            grid = !grid
            binding.recycler.layoutManager =
                if (grid) GridLayoutManager(this, 2) else LinearLayoutManager(this)
            binding.btnToggle.text = if (grid) "Switch to List" else "Switch to Grid"
        }
    }
}
