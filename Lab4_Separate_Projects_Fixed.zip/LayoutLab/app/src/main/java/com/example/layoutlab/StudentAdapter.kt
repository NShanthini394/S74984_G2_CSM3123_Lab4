package com.example.layoutlab

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.layoutlab.databinding.ItemStudentBinding

data class Student(val name: String, val score: Int)

class StudentAdapter(
    private val items: List<Student>,
    private val onClick: (Student) -> Unit
) : RecyclerView.Adapter<StudentAdapter.VH>() {
    class VH(val binding: ItemStudentBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        Log.d("Recycler", "create") // Exercise 6, Modify 1: observe reuse
        val binding = ItemStudentBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        Log.d("Recycler", "bind $position") // Compare log count with create
        val student = items[position]
        holder.binding.txtName.text = student.name
        holder.binding.txtScore.text = "Marks: ${student.score}"
        holder.binding.root.setOnClickListener { onClick(student) }
    }

    override fun getItemCount(): Int = items.size
}
