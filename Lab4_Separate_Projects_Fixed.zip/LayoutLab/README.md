# LayoutLab — View-based project (Exercises 1–6)

Create/open a project with Android Studio **Empty Views Activity**, name **LayoutLab**,
Kotlin, minSdk 24+. This source set contains the six View-based exercises, plus challenges.

Gradle uses Kotlin `compilerOptions` with JVM target 17. Compose is NOT enabled here.
The Gradle wrapper distribution is set to 8.14.4 (required files downloaded during first sync).
If using a newly created project, copy the app/src/main source files and app/build.gradle.kts
configurations into it, preserving the project-generated Gradle Wrapper and Gradle JDK 17.

The separate `ComposeLab` folder has Exercise 7.
**Build and emulator operation were not tested in this environment.**
