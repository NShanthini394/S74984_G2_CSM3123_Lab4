Lab 4: Corrected Gradle source files

RECOMMENDED SPLIT (as prescribed on lab PDF page 14):
- LayoutLab/ contains Exercises 1–6 (Views XML) and extra challenges.
- ComposeLab/ contains Exercise 7 (MainActivity.kt, Compose UI).

ALTERNATIVE:
- LayoutLab_Combined/ is the repaired version of the previously shared source,
  preserving all seven exercises in one Android application.

Main error fix: delete android { kotlinOptions { jvmTarget = "17" } }
and add outside android { kotlin { compilerOptions { jvmTarget.set(
org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } } }.

NOTE: The ZIP is source-only; no gradle-wrapper.jar or gradlew scripts are included.
If import fails to initialize Gradle, create a fresh project in Android Studio
from the appropriate template and copy app sources and the needed dependencies.

The Gradle version setting has been raised from 8.13 to 8.14.4.
The source has not been compiled, synced or run on an emulator here.
