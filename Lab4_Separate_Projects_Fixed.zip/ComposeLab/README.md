# ComposeLab — Exercise 7 only

The lab PDF (page 14, Exercise 7 Setup) recommends a **separate Empty Activity**
Jetpack Compose project called ComposeLab.

1. In Android Studio: **New Project > Empty Activity** (Compose), Name: ComposeLab,
   Package: `com.example.composelab`, Minimum SDK 24 or newer.
2. Replace your generated app/src/main/java/com/example/composelab/MainActivity.kt
   with the file in this folder.
3. If the template versions differ, prefer keeping its generated Gradle configuration,
   so long as Jetpack Compose Material3, foundation and activity-compose are available.
   Or use the included build.gradle.kts with JDK 17 and Gradle 8.14.4.
4. Sync, run, and use the Register/Students/Box tabs for Exercise 7 and its challenges.

This source-only copy lacks Gradle Wrapper JAR/scripts. Creating the project in
Android Studio provides the wrapper and avoids import errors.
No emulator run was possible here.
