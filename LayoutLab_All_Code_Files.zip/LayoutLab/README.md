# LayoutLab - Lab 4: Experimenting with Android Layout Containers

**CSM3123 Native Mobile Programming - Chapter 4 User Interface**

This source project implements **all seven core exercises** in the provided 19-page lab,
with a launcher menu, plus the Make/challenge and layout-comparison screens.
The seventh Compose exercise is included **in the same Android project** using the
Compose Compiler Gradle plugin, instead of a second project suggested as the
safest setup option on page 14. All work is in Kotlin.

## Start in Android Studio

1. Extract the `LayoutLab` folder from the ZIP.
2. Open Android Studio -> **Open** -> select the extracted `LayoutLab` folder.
3. Install Android SDK Platform 36 and a Pixel emulator in SDK Manager if needed.
4. Use JDK 17 or newer as the Gradle JDK (JDK 17 is the usual safe choice).
5. This source-only archive does not embed `gradle-wrapper.jar`, because no Gradle
   distribution was available in the packaging environment. To get a working wrapper,
   either create a fresh Empty Views Activity project with the name `LayoutLab` using
   Android Studio and copy the files here into it, or run `gradle wrapper
   --gradle-version 8.13` once if Gradle is installed. Then **Sync Project with Gradle Files**.
6. Run on an emulator or Android device. Main menu opens the six View layouts,
   Compose screen and additional challenge/comparison examples.

## Core screens

| Exercise | Activity | XML / Compose |
|---|---|---|
| 1 LinearLayout | LinearActivity.kt | activity_linear.xml |
| 2 RelativeLayout | RelativeActivity.kt | activity_relative.xml |
| 3 ConstraintLayout | ConstraintActivity.kt | activity_constraint.xml |
| 4 FrameLayout | FrameActivity.kt | activity_frame.xml |
| 5 TableLayout | TableActivity.kt | activity_table.xml |
| 6 RecyclerView | RecyclerActivity.kt, StudentAdapter.kt | activity_recycler.xml, item_student.xml |
| 7 Compose | ComposeActivity.kt | RegisterScreen, StudentList, FrameBoxScreen |

**Bonus Make challenges:** calculator (4x4), RelativeLayout centered double-button group,
ConstraintLayout packed horizontal chain and 50% guideline, product card with toggleable
ProgressBar, two-column table form, Compose Box and student tap Toast/Logcat logging.

**Comparison exercise:** the RelativeLayout version is Exercise 2. In the menu open
`Comparison: Linear profile` and `Comparison: Constraint profile` for the other two.

## Important use of this package

- Baseline XML values match the lab's **Run** steps; experiment changes are **not** left
  enabled, since each experiment says to restore the original before the next.
- The optional Make/challenge screens are separate so baseline examples remain clear.
- Do not submit `EXPECTED_ANSWERS.md` as observed results without testing: predictions
  and expected outcomes are provided, but Layout Inspector measurements and emulator
  outcomes must be recorded from your own run.
- Filter Logcat with tag `Recycler`; `create` is usually called far less than `bind`.
- View Binding is enabled; `activity_main.xml` and each View Activity have a root `@+id/main`.
- The `Insets.kt` helper preserves XML's 16dp padding while applying system bar insets.

## Build notes

Gradle plugin versions are selected to be mutually compatible with the 2026 lab:
AGP 8.13.2, Kotlin + Compose compiler 2.4.10, Compose BOM 2026.09.00,
RecyclerView 1.4.0, minimum SDK API 24, target SDK API 35, compile SDK API 36.
First Gradle sync downloads AndroidX libraries and the Gradle distribution.
**The project has not been built or run in an emulator in this environment.**

See `EXPECTED_ANSWERS.md` and `EXPERIMENT_LOG_TEMPLATE.csv` for written questions.
